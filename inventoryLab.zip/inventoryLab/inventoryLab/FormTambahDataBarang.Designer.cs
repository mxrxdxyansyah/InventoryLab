﻿namespace inventoryLab
{
    partial class FormTambahDataBarang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            textBox4 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            textBox5 = new TextBox();
            comboBox1 = new ComboBox();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(135, 168);
            button2.Name = "button2";
            button2.Size = new Size(46, 23);
            button2.TabIndex = 21;
            button2.Text = "Batal";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(79, 168);
            button1.Name = "button1";
            button1.Size = new Size(56, 23);
            button1.TabIndex = 20;
            button1.Text = "Simpan";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(65, 27);
            label6.Name = "label6";
            label6.Size = new Size(10, 15);
            label6.TabIndex = 19;
            label6.Text = ":";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(65, 85);
            label5.Name = "label5";
            label5.Size = new Size(10, 15);
            label5.TabIndex = 18;
            label5.Text = ":";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(66, 56);
            label4.Name = "label4";
            label4.Size = new Size(10, 15);
            label4.TabIndex = 17;
            label4.Text = ":";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 86);
            label3.Name = "label3";
            label3.Size = new Size(30, 15);
            label3.TabIndex = 16;
            label3.Text = "Stok";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 57);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 15;
            label2.Text = "Nama";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 28);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 14;
            label1.Text = "Kode";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(79, 81);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(158, 23);
            textBox3.TabIndex = 13;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(79, 52);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(158, 23);
            textBox2.TabIndex = 12;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(79, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(158, 23);
            textBox1.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(65, 114);
            label7.Name = "label7";
            label7.Size = new Size(10, 15);
            label7.TabIndex = 24;
            label7.Text = ":";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 115);
            label8.Name = "label8";
            label8.Size = new Size(26, 15);
            label8.TabIndex = 23;
            label8.Text = "Rak";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(147, 111);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(90, 23);
            textBox4.TabIndex = 22;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(65, 143);
            label9.Name = "label9";
            label9.Size = new Size(10, 15);
            label9.TabIndex = 27;
            label9.Text = ":";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(20, 144);
            label10.Name = "label10";
            label10.Size = new Size(39, 15);
            label10.TabIndex = 26;
            label10.Text = "Status";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(79, 139);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(158, 23);
            textBox5.TabIndex = 25;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(79, 111);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(66, 23);
            comboBox1.TabIndex = 28;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // FormTambahDataBarang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(263, 231);
            Controls.Add(comboBox1);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(textBox5);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(textBox4);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "FormTambahDataBarang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tambah Data Barang";
            Load += FormTambahDataBarang_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label7;
        private Label label8;
        private TextBox textBox4;
        private Label label9;
        private Label label10;
        private TextBox textBox5;
        private ComboBox comboBox1;
    }
}