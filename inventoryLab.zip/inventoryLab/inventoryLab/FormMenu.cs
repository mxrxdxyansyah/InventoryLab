﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace inventoryLab
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {

        }

        private void buttonpgn_Click(object sender, EventArgs e)
        {
            TampilDataPengguna tpn = new TampilDataPengguna();
            tpn.TopLevel = false; tpn.TopMost = true;
            panelTampil.Controls.Add(tpn);
            tpn.BringToFront();
            tpn.Show();
        }

        private void buttonaslab_Click(object sender, EventArgs e)
        {
            TampilDataAslab tpl = new TampilDataAslab();
            tpl.TopLevel = false; tpl.TopMost = true;
            panelTampil.Controls.Add(tpl);
            tpl.BringToFront();
            tpl.Show();
        }

        private void buttonbrg_Click(object sender, EventArgs e)
        {
            TampilDataBarang tpb = new TampilDataBarang();
            tpb.TopLevel = false; tpb.TopMost = true;
            panelTampil.Controls.Add(tpb);
            tpb.BringToFront();
            tpb.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FormTambahRak FTR = new FormTambahRak();
            FTR.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TampilPeminjaman Tpinjam = new TampilPeminjaman();
            Tpinjam.TopLevel = false; Tpinjam.TopMost = true;
            panelTampil.Controls.Add(Tpinjam);
            Tpinjam.BringToFront();
            Tpinjam.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TampilPengembalian Tback = new TampilPengembalian();
            Tback.TopLevel = false; Tback.TopMost = true;
            panelTampil.Controls.Add(Tback);
            Tback.BringToFront();
            Tback.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Apakah Anda ingin Keluar Aplikasi?", "Konfirmasi", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
