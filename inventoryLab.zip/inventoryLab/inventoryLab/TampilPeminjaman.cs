﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.DataFormats;

namespace inventoryLab
{
    public partial class TampilPeminjaman : Form
    {
        public TampilPeminjaman()
        {
            InitializeComponent();
        }
        KoneksiDB ConnDB = new KoneksiDB();
        private void TampilPeminjaman_Load(object sender, EventArgs e)
        {
            BindxSoucre();
            setGrid();
        }
        public void BindxSoucre()
        {

            // membuka koneksi db || pilih query
            ConnDB.Koneksi();
            ConnDB.OleAdapter = new OleDbDataAdapter("SELECT peminjaman.tanggal_masuk,peminjaman.nomor_masuk,barang.nama_barang,aslab.nama_aslab FROM ((peminjaman INNER JOIN barang ON peminjaman.kode_barang = barang.kode_barang) INNER JOIN aslab ON peminjaman.kode_aslab = aslab.kode_aslab)", ConnDB.conn);
            DataSet ds = new DataSet();
            ConnDB.OleAdapter.Fill(ds);

            //menampilkan kedalam table
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.ReadOnly = true;

            //menutup koneksi db
            ConnDB.conn.Close();

        }
        void setGrid()
        {
            dataGridView1.Columns["tanggal_masuk"].Width = 150;
            dataGridView1.Columns["nomor_masuk"].Width = 150;
            dataGridView1.Columns["nama_barang"].Width = 150;
            dataGridView1.Columns["nama_aslab"].Width = 150;


            dataGridView1.Columns["tanggal_masuk"].HeaderText = "TANGGAL";
            dataGridView1.Columns["nomor_masuk"].HeaderText = "NOMOR";
            dataGridView1.Columns["nama_barang"].HeaderText = "BARANG";
            dataGridView1.Columns["nama_aslab"].HeaderText = "ASLAB"; ;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
}
